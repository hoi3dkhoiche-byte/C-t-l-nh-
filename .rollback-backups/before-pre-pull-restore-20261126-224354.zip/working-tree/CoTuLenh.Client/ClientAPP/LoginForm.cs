using System.Text.Json;

namespace ClientAPP;

public partial class LoginForm : BaseForm
{
    private readonly string rememberFilePath = "remember.json";

    public LoginForm()
    {
        InitializeComponent();
    }

    // 1. Tự động đọc địa chỉ Server LAN và tài khoản đã ghi nhớ khi form vừa mở lên
    private void Form1_Load(object sender, EventArgs e)
    {
        txtServerUrl.Text = ServerConfig.BaseUrl;

        try
        {
            if (File.Exists(rememberFilePath))
            {
                string json = File.ReadAllText(rememberFilePath);
                var data = JsonSerializer.Deserialize<RememberData>(json);

                if (data != null && data.IsRemember)
                {
                    txtUsername.Text = data.Username;
                    txtPassword.Text = data.Password;
                    chkRememberMe.Checked = true;
                }
            }
        }
        catch
        {
            // Bỏ qua nếu file hỏng
        }
    }

    private bool ApplyServerUrlInput()
    {
        if (!ServerConfig.TrySetBaseUrl(txtServerUrl.Text, out string err))
        {
            lblErrorMessage.Text = err;
            txtServerUrl.Focus();
            return false;
        }

        txtServerUrl.Text = ServerConfig.BaseUrl;
        return true;
    }

    // 2. Đăng nhập và khởi tạo kết nối Socket.IO xác thực JWT
    private async void btnLogin_Click(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";

        if (!ApplyServerUrlInput()) return;

        string username = txtUsername.Text.Trim();
        string password = txtPassword.Text;

        if (string.IsNullOrEmpty(username))
        {
            lblErrorMessage.Text = "Vui lòng nhập tên đăng nhập hay email của bạn!";
            txtUsername.Focus();
            return;
        }

        if (string.IsNullOrEmpty(password))
        {
            lblErrorMessage.Text = "Vui lòng nhập mật khẩu!";
            txtPassword.Focus();
            return;
        }

        btnLogin.Enabled = false;
        btnLogin.Text = "Đang kết nối...";

        try
        {
            var result = await AuthService.LoginAsync(username, password);

            if (result.Success)
            {
                // === XỬ LÝ GHI NHỚ ĐĂNG NHẬP ===
                if (chkRememberMe.Checked)
                {
                    var data = new RememberData
                    {
                        Username = username,
                        Password = password,
                        IsRemember = true
                    };
                    string json = JsonSerializer.Serialize(data);
                    File.WriteAllText(rememberFilePath, json);
                }
                else if (File.Exists(rememberFilePath))
                {
                    File.Delete(rememberFilePath);
                }

                var currentUser = result.User ?? new UserModel
                {
                    Username = username,
                    Email = username.Contains("@") ? username : $"{username}@cotulenh.vn",
                    Coins = 0,
                    EloRating = 1200,
                    Reputation = 10
                };

                SessionService.Instance.SetCurrentUser(currentUser, result.Token);
                GameApiService.Instance.CacheUser(currentUser.Id, currentUser.Username);

                // Kết nối Socket.IO kèm JWT token của tài khoản vừa đăng nhập
                await RealtimeService.Instance.ConnectAsync(forceReconnect: true);

                var lobby = new LobbyForm();
                lobby.Show();
                this.Hide();
            }
            else
            {
                lblErrorMessage.Text = result.Message;
            }
        }
        catch (Exception ex)
        {
            lblErrorMessage.Text = $"Lỗi: {ex.Message}";
        }
        finally
        {
            btnLogin.Enabled = true;
            btnLogin.Text = "Đăng nhập";
        }
    }

    private void txtUsername_TextChanged(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";
    }

    private void txtPassword_TextChanged(object sender, EventArgs e)
    {
        lblErrorMessage.Text = "";
    }

    private void btnRegister_Click(object sender, EventArgs e)
    {
        if (!ApplyServerUrlInput()) return;

        RegisterForm registerForm = new RegisterForm();
        registerForm.FormClosed += (s, args) => this.Show();
        registerForm.Show();
        this.Hide();
    }

    private void lnkForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
        if (!ApplyServerUrlInput()) return;

        ForgotPasswordForm forgotForm = new ForgotPasswordForm();
        forgotForm.FormClosed += (s, args) => this.Show();
        forgotForm.Show();
        this.Hide();
    }

    private void label2_Click(object sender, EventArgs e) { }
    private void label1_Click(object sender, EventArgs e) { }
    private void chkRememberMe_CheckedChanged(object sender, EventArgs e) { }
    private void lblErrorMessage_Click(object sender, EventArgs e) { }
    private void lblTitle_Click(object sender, EventArgs e) { }
}

public class RememberData
{
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public bool IsRemember { get; set; }
}
